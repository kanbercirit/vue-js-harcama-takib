<?php
define('Tamam', 'Tamam');
define('Hata', 'Hata');
define('Veriler', 'Veriler');
define('BlokDisi', 'Blok Dışı');