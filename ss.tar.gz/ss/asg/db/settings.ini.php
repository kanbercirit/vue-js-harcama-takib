;<?php return; ?>
[SQL]
driver = mysql
host = localhost
username = root
password = Maria55
database = asg_hss
charset = utf8
collation = utf8_unicode_ci